package com.example.hostelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Button nextpage;
    SharedPreferences sharedpreferences;
    String str;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        nextpage = findViewById(R.id.nextpage);



        sharedpreferences = getApplicationContext().getSharedPreferences("MyPrefs", MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedpreferences.edit();

        str = sharedpreferences.getString("str",null);

        if(str!=null) {
            Intent log = new Intent(getApplicationContext(), list.class);
            startActivity(log);

            str = "a";
        }
        nextpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putString("str",str);
                editor.commit();
                Intent Sign = new Intent(getApplicationContext(), list.class);
                startActivity(Sign);
            }
        });




    }
}
